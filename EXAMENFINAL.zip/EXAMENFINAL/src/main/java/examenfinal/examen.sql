-- Crear la base de datos
CREATE DATABASE Autoras;

-- Usar la base de datos
USE Autoras;

-- Crear la tabla Autoras
CREATE TABLE Autoras (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellidos VARCHAR(50) NOT NULL,
  alias VARCHAR(50),
  fecha_nacimiento DATE NOT NULL,
  premios_recibidos INT,
  pais_residencia VARCHAR(50),
  area_trabajo VARCHAR(50)
);


-- Insertar datos en la tabla Autoras
INSERT INTO Autoras (nombre, apellidos, alias, fecha_nacimiento, premios_recibidos, pais_residencia, area_trabajo)
VALUES
  ('Isabel', 'Valdés', '', '1970-06-15', 2, 'España', 'Periodista'),
  ('Barbie', 'Japuta', 'Barbiejaputa', '1988-03-25', 0, 'España', 'Activista'),
  ('Adela', 'Cortina', '', '1947-11-24', 5, 'España', 'Filósofa'),
  ('Irene', 'Vallejo', '', '1979-08-03', 3, 'España', 'Escritora'),
  ('Leticia', 'Dolera', '', '1981-10-23', 1, 'España', 'Directora de cine'),
  ('Gabriela', 'Lardies', 'Lardies', '1992-02-10', 1, 'España', 'Escritora'),
  ('Cristina', 'Morató', '', '1971-07-02', 4, 'España', 'Periodista'),
  ('María', 'Dueñas', '', '1964-07-06', 2, 'España', 'Escritora'),
  ('Ana', 'Merino', '', '1971-08-26', 1, 'España', 'Poeta'),
  ('Nancy', 'Fernández', '', '1980-05-12', 0, 'España', 'Escritora'),
  ('Laura', 'Freixas', '', '1958-07-26', 3, 'España', 'Escritora'),
  ('Clara', 'Sánchez', '', '1955-03-01', 2, 'España', 'Escritora'),
  ('Almudena', 'Grandes', '', '1960-05-07', 7, 'España', 'Escritora'),
  ('Carme', 'Riera', '', '1948-01-12', 6, 'España', 'Escritora'),
  ('Lola', 'Herrera', '', '1970-04-19', 1, 'España', 'Actriz'),
  ('Carmen', 'Posadas', '', '1953-08-13', 4, 'España', 'Escritora'),
  ('Laura', 'González', 'Lagus', '1986-12-09', 0, 'España', 'Escritora'),
  ('Marta', 'Sanchez', 'Martuki', '1990-09-05', 0, 'España', 'Escritora'),
  ('Sara', 'Herrera', 'Sarapico', '1995-03-30', 0, 'España', 'Poeta'),
  ('María', 'Cabrera', 'Mariacab', '1993-07-17', 1, 'España', 'Escritora');

-- Insertar datos en la tabla Autoras
INSERT INTO Autoras (nombre, apellidos, alias, fecha_nacimiento, premios_recibidos, pais_residencia, area_trabajo)
VALUES
  ('Gabriela', 'Mistral', '', '1889-04-07', 3, 'Chile', 'Poeta'),
  ('Isabel', 'Allende', '', '1942-08-02', 8, 'Chile', 'Escritora'),
  ('Elena', 'Poniatowska', '', '1932-05-19', 7, 'México', 'Escritora'),
  ('Laura', 'Esquivel', '', '1950-09-30', 1, 'México', 'Escritora'),
  ('Gioconda', 'Bell', '', '1948-11-10', 2, 'Colombia', 'Escritora'),
  ('Silvina', 'Ocampo', '', '1903-07-28', 0, 'Argentina', 'Escritora'),
  ('Valeria', 'Luiselli', '', '1983-08-16', 2, 'México', 'Escritora'),
  ('Isabel', 'Coixet', '', '1960-04-09', 4, 'España', 'Directora de cine'),
  ('Juana', 'Moliner', '', '1928-09-19', 1, 'Argentina', 'Escritora'),
  ('Rita', 'Indiana', '', '1977-06-25', 0, 'República Dominicana', 'Escritora'),
  ('Juana', 'Inés', 'JuanaInes', '1651-11-12', 0, 'México', 'Escritora'),
  ('Clarice', 'Lispector', '', '1920-12-10', 1, 'Brasil', 'Escritora'),
  ('Violeta', 'Parra', '', '1917-10-04', 0, 'Chile', 'Compositora'),
  ('Gloria', 'Fuertes', '', '1917-07-28', 2, 'España', 'Poeta'),
  ('Nélida', 'Piñón', '', '1937-05-03', 6, 'Brasil', 'Escritora'),
  ('Rosario', 'Castellanos', '', '1925-05-25', 2, 'México', 'Escritora'),
  ('Gabriela', 'Arias', 'Gabyarias', '1976-03-12', 1, 'Argentina', 'Periodista'),
  ('Aurora', 'Venturini', '', '1922-11-20', 0, 'Argentina', 'Escritora'),
  ('María', 'Wernicke', '', '1972-02-03', 0, 'Argentina', 'Ilustradora'),
  ('Olga', 'Nolla', '', '1946-09-18', 3, 'Puerto Rico', 'Escritora');

-- Insertar datos en la tabla Autoras
INSERT INTO Autoras (nombre, apellidos, alias, fecha_nacimiento, premios_recibidos, pais_residencia, area_trabajo)
VALUES
  ('Margarita', 'Salas', '', '1945-11-30', 2, 'España', 'Bioquímica'),
  ('Elsa', 'López', '', '1970-09-12', 1, 'Argentina', 'Genetista'),
  ('Ana', 'Belén', '', '1965-05-20', 0, 'España', 'Física'),
  ('María', 'Blasco', '', '1965-11-11', 6, 'España', 'Biomedicina'),
  ('Luisa', 'Carpio', '', '1980-03-02', 0, 'España', 'Ingeniera'),
  ('Lina', 'Galindo', '', '1978-07-15', 3, 'Colombia', 'Geóloga'),
  ('Carmen', 'Hernández', '', '1963-12-18', 1, 'España', 'Química'),
  ('Beatriz', 'Jurado', '', '1982-02-05', 0, 'España', 'Astrofísica'),
  ('Isabel', 'López', '', '1974-04-23', 2, 'España', 'Matemática'),
  ('Ana', 'Moreno', '', '1985-09-07', 0, 'España', 'Biología'),
  ('María', 'Núñez', '', '1976-06-09', 1, 'España', 'Informática'),
  ('Laura', 'Ortega', '', '1988-11-14', 0, 'México', 'Ingeniera'),
  ('Sara', 'Pérez', '', '1990-08-20', 1, 'España', 'Neurocientífica'),
  ('Patricia', 'Ramírez', '', '1977-03-27', 0, 'España', 'Psicóloga'),
  ('Valeria', 'Rodríguez', '', '1984-01-12', 2, 'Argentina', 'Bioquímica'),
  ('Sofía', 'Santos', '', '1992-07-30', 0, 'España', 'Física'),
  ('Laura', 'Torres', '', '1986-09-25', 1, 'Colombia', 'Ingeniera'),
  ('María', 'Vargas', '', '1973-05-18', 3, 'España', 'Astrónoma'),
  ('Natalia', 'Vega', '', '1981-12-02', 1, 'España', 'Biomedicina'),
  ('Lorena', 'Zamora', '', '1979-08-09', 0, 'España', 'Química');

