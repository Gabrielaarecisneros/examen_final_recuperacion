/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenfinal;

import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author eclipse
 */
public class EXAMEN {

 
    public static Scanner cs = new Scanner(System.in);

    public static void comprueba(int resultado) throws Exception {
        if (resultado == 1) {
            System.out.println("ejecutado ");
        } else {
            throw new Exception("error ");
        }
    }

    public static void comprueba(boolean resultado) throws Exception {
        if (!resultado) {
            System.out.println("listo ");
        } else {
            throw new Exception("Error");
        }
    }

    public static void main(String[] args) {

        try {
/*añadiendo  para  que le  lea  myql */
            
             Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://10.230.109.223?serverTimezone=UTC";
            Connection conn = DriverManager.getConnection(url, "root", "");
            String filePath = "C:\\Users\\DAW\\Documents\\NetBeansProjects\\examen.sql";
         

            int bd;
            boolean EXTRAER = true;    

            EXTRAER = stmt.execute("USE Autes;");
            System.out.println("USE Autes");
            comprueba(EXTRAER);
                          
            String ruta = "Resuelto";
            File resultado = new File(ruta);
            if (!resultado.exists()) {
                resultado.mkdir();
            }
             System.out.println("opciones  .");
            System.out.println("introduce el nombre de la carpeta .");
           
            String nombre = cs.nextLine();
            FileWriter writer = new FileWriter(ruta + File.separator + nombre + ".txt", false);

            int opcion = 0;
      
        System.out.println("MENÚ");
        System.out.println("1. Mostrar datos de una autores");
        System.out.println("2. Mostrar autora con más premios");
        System.out.println("3. Mostrar número de autoras por país de residencia");
        System.out.println("4. Mostrar número de autoras por campo de trabajo");
        System.out.println("5. Agregar una autora");
        System.out.println("6. Salir");
/*consultas*/
            do {
                switch (opcion) {
                    case 1:                                                                                                                         
                        ResultSet autora = stmt.executeQuery("SELECT * FROM Autoras WHERE nombre= 'Ana';");
                        while (autora.next()) {
                            System.out.println(""
                                    + "id: " + autora.getInt("id")
                                    + ", nombre: " + autora.getString("nombre")
                                    + ", alias: " + autora.getString("alias")
                                    + ", fecha de nacimiento: " + autora.getDate("fecha_nacimiento")
                                    + ", premios recibidos: " + autora.getInt("premios_recibidos")
                                    + ", país de residencia: " + autora.getString("pais_residencia")
                                    + ", área de trabajo: " + autora.getString("area_trabajo"));
                            writer.write(""
                                    + "id: " + autora.getInt("id")
                                    + ", nombre: " + autora.getString("nombre")
                                    + ", alias: " + autora.getString("alias")
                                    + ", fecha de nacimiento: " + autora.getDate("fecha_nacimiento")
                                    + ", premios recibidos: " + autora.getInt("premios_recibidos")
                                    + ", país de residencia: " + autora.getString("pais_residencia")
                                    + ", área de trabajo: " + autora.getString("area_trabajo"));
                            
                            System.out.println("");
                        }
                        break;
                    case 2:
                        ResultSet premios = stmt.executeQuery("SELECT nombre ,premios_recibidos FROM Autoras WHERE premios_recibidos=8 ;");//consulta
                        while (premios.next()) {
                            System.out.println(
                                    "nombre ," + premios.getString("nombre")
                                    + "Premios recibidos ," + premios.getString("premios_recibidos"));


                            writer.write(
                                    "nombre ," + premios.getString("nombre")
                                    + "Premios recibidos ," + premios.getString("premios_recibidos"));
                            break;
                        }
                        break;
                    case 3:
                        ResultSet pais = stmt.executeQuery("SELECT count(*),pais_residencia  FROM Autoras group by pais_residencia ;");//consulta
                        while (pais.next()) {
                            System.out.println(
                                    "id ," + pais.getInt("id")
                                    + "nombre ," + pais.getString("nombre")
                                    + "alias ," + pais.getString("alias")
                                    + "fecha nacimiento ," + pais.getDate("fecha_nacimiento")
                                    + "premios recibidos ," + pais.getInt("premios_recibidos")
                                    + "pais residencia ," + pais.getString("pais_residencia")
                                    + "area de trabajo ," + pais.getString("area_trabajo"));

                            writer.write(
                                    "id ," + pais.getInt("id")
                                    + "nombre ," + pais.getString("nombre")
                                    + "alias ," + pais.getString("alias")
                                    + "fecha nacimiento ," + pais.getDate("fecha_nacimiento")
                                    + "premios recibidos ," + pais.getInt("premios_recibidos")
                                    + "pais residencia ," + pais.getString("pais_residencia")
                                    + "area de trabajo ," + pais.getString("area_trabajo"));
                            
                            System.out.println("");
                        }
                        break;
                    case 4:
                        ResultSet trabajo = stmt.executeQuery(" SELECT count(*), area_trabajo FROM Autoras group by area_trabajo ");//consulta
                        while (trabajo.next()) {
                            System.out.println(
                                    "id ," + trabajo.getInt("id")
                                    + "nombre ," + trabajo.getString("nombre")
                                    + "alias ," + trabajo.getString("alias")
                                    + "fecha nacimiento ," + trabajo.getDate("fecha_nacimiento")
                                    + "premios recibidos ," + trabajo.getInt("premios_recibidos")
                                    + "pais residencia ," + trabajo.getString("pais_residencia")
                                    + "area de trabajo ," + trabajo.getString("area_trabajo"));

                            writer.write("id ," + trabajo.getInt("id")
                                    + "nombre ," + trabajo.getString("nombre")
                                    + "alias ," + trabajo.getString("alias")
                                    + "fecha nacimiento ," + trabajo.getDate("fecha_nacimiento")
                                    + "premios recibidos ," + trabajo.getInt("premios_recibidos")
                                    + "pais residencia ," + trabajo.getString("pais_residencia")
                                    + "area de trabajo ," + trabajo.getString("area_trabajo"));
                            
                            System.out.println("");
                        }
                        break;
                    case 5:               
                        System.out.println("introduce id");
                        int id = cs.nextInt();
                        System.out.println("introduce nombre");
                        String nombreAutora = cs.nextLine();
                        System.out.println("introduce alias");
                        String alias = cs.nextLine();
                        System.out.println("introduce fecha de nacimiento");
                        String fecha = cs.nextLine();
                        System.out.println("introduce premio");
                        int premio = cs.nextInt();
                        System.out.println("introduce pais");
                        String paisAutora = cs.nextLine();
                        System.out.println("introduce area de trabajo");
                        String areaTrabajo = cs.nextLine();

                        EXTRAER = stmt.execute("insert into Autoras(id,nombre,alias,fecha_nacimiento,premios_recibidos,pais_residencia,area_trabajo"
                                + "value(" + id + "," + nombreAutora + "," + alias + "," + fecha + "," + premio + "," + paisAutora + "," + areaTrabajo + ")");//insert
                        
                        break;
                }
            } while (opcion != 6);


            writer.close();
            stmt.close();
            conn.close();
       
        } catch (Exception e) {
            System.out.println("error");
            e.printStackTrace();
        }
    }
}
